export default function bar() {
    console.log('work');
}